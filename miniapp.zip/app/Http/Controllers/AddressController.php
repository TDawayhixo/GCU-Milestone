<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use app\data\AddAddress;



class AddressController extends Controller
{
   public function AddAddress(Request $request)
   {
       echo "this is a Test";
       $firstname = $request()->get('firstname');
       $lastname = $request()->get('lastname');
       $email = $request()->get('email');
       $address = $request()->get('address');
       $city = $request()->get('city');
       $state = $request()->get('state');
       $zip = $request()->get('zip');
       
       $user = new AddAddress($firstname, $lastname, $email, $address, $city, $state, $zip);
       
       $service = new AddAddress();
      $result = $service->AddAddress($user);
      
      if ($result) {
          
          return view('home');          
      }
      
      else {
          return view('home');
      }
   }
  
}
