<?php

namespace App\Models;

use mysqli;

class db_connect
{
    private $dbhost = "";
    private $dbuser = "";
    private $dbpass = "";
    private $dbname = "";
    private $port = "";
    
    
    
    function connect () {
        $this->dbhost = 'localhost';
        $this->dbuser = 'root';
        $this->dbpass = 'root';
        $this->dbname = 'miniapp';
        $this->port = '8889';
        
        
        
        
        $this->conn = new mysqli($this->dbhost, $this->dbuser, $this->dbpass, $this->dbname, $this->port);
        
        if ($this->conn->connect_error)
        {
            die('Failed to connect to MySql - ' . $this->conn->connect_error);
        }
        
        return $this->conn;
        
    }
}



?>
