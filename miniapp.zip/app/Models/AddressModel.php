<?php

namespace App\Models;

class AddressModel 
{
    // made private only to be access in addressmodel
    private $firstname;
    private $lastname;
    private $email;
    private $address;
    private $city;
    private $state;
    private $zip;
    
    function function_name() {
        ;
    }
}