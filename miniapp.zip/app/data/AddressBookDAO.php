<?php
namespace App\data;

use app\data\db_connect;
use app\services\Address;

error_reporting(E_ALL);
ini_set('display_errors', 1);



class AddressBookDAO 
{
    public function deleteUser($user)
    {
        $id = $user->getId();
        
        $sql_statment  = "DELETE FROM `address` WHERE `address`.`ID` = '$id'";
        
        $results = $this->connect()->query($sql_statment);
        
        if ($results) {
            return true;
        }
        return false;
        
        
    }
    
    public function updateUser($user) {
        
        $id = $user->getId();
        $fname = $user->getFName();
        $lname = $user->getLName();
        $email = $user->getEmail();
        $address = $user->getAddress();
        $city = $user->getCity();
        $state = $user->getState();
        $zipcode = $user->getZipCode();
        
        
        $sql_statment  = "UPDATE address SET  First_Name = '$fname', Last_Name ='$lname', Email ='$email', Address ='$address', City ='$city', State ='$state', Zip_Code ='$zipcode' WHERE ID = '$id'";
        
        $results = $this->connect()->query($sql_statment);
        
        if ($results) {
            return true;
        }
        return false;
        
        
    }
    
    // working!
    public function getAlluser()
    {
        
        $dbconnect = new db_connect();
        $this->connect = $dbconnect->connect();
        
        
        $sql = "SELECT * FROM address";
        
        $results = $this->connect()->query($sql);
        
        $numRows = $results->num_rows;
        
        if ($numRows > 0)
        {
            $listofeveryone = [];
            while( $row = $results->fetch_array(MYSQLI_ASSOC))
            {
                
                $u = new Address($row['ID'], $row['First_Name'], $row['Last_Name'], $row['Email'], $row['Address'], $row['City'], $row['State'], $row['Zip_Code']);
                array_push($listofeveryone, $u);
            }
            
            return $listofeveryone;
            
            
            
        }
    }
}
?>