<?php
namespace App\data;

error_reporting(E_ALL);
ini_set('display_errors', 1);

use app\data\db_connect;

class AddAddress
{
    public function AddAddress()
    {    
    $Fname = $_POST['FirstName'];
    $Lname = $_POST['LastName'];
    $Address = $_POST['Address'];
    $Uname = $_POST['City'];
    $State = $_POST['State'];
    $Email = $_POST['Email'];
    $ZipCode = $_POST['ZipCode'];

$db = new db_connect();

$connection =$db->connect();


$sql_statment  = "INSERT INTO `address`(`ID`, `First_Name`, `Last_Name`, `Email`, `Address`,`City`,`Zip_Code`) VALUES ('', '$Fname', '$Lname', '$Email', '$Address', '$Uname', '$State', '$ZipCode')";
if ($connection->query($sql_statment) === TRUE){
    echo " New record created successfully";
    echo " Click <a href=homeblade.php> here when finish.<a/>";
    
}
else {
    echo "Error " . $sql_statment . "<br>" . $connection->error;
}

$connection->close();

    }
}
?>