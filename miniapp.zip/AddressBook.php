<?php

include_once 'db_connect.php';
include_once 'AddressBookDAO.php';


class users
{
    public function Get_All_user()
    {
        $all_data = $this->getAlluser();
        foreach($all_data as $row)
        {
            $data[] = $row;
        }
        return $data;
    }
}